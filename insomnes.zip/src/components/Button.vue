<template>
  <div class="botones">
    <div class="icons">
      <a href="https://wa.me/541124026001" target="_blank" class="wp"><i class="bx bxl-whatsapp bx-md"></i></a>
      <a href="mailto:ed.insomnes@gmail.com" target="_blank" class="gm"><i class="bx bxl-gmail bx-md" aria-hidden="true"></i></a>
    </div>
  </div>
</template>
<style scoped>
</style>
<script>
export default {
  name: "ButtonComponent",
};
</script>
